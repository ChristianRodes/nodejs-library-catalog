import "./ListadoLibros.css"
import biblioteca from "../assets/bbdd/biblioteca.json"
import Libro from "./Libro"

const ListadoLibros = () => {
  const { libros } = biblioteca

  if (!Array.isArray(libros) || libros.length === 0) {
    return <p>No se han encontrado libros.</p>
  }

  return (
    <section className="listado-libros">
      <h2 className="listado-libros__titulo">Listado de libros</h2>

      <div className="listado-libros__grid">
        {libros.map((libro) => (
          <Libro key={libro.id} libro={libro} />
        ))}
      </div>
    </section>
  )
}

export default ListadoLibros
