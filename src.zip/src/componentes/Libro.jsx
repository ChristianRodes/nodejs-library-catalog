import "./Libro.css"
import sinPortada from "../assets/img/sin_portada.png"

const Libro = ({ libro }) => {
  const {
    id,
    titulo = "No se ha especificado título",
    autor = "No se ha especificado autor",
    portada
  } = libro

  return (
    <article id={id} className="libro">
      <img
        className="libro__imagen"
        src={portada ? portada : sinPortada}
        alt={`Portada de ${titulo}`}
      />

      <h3 className="libro__titulo">{titulo}</h3>
      <p className="libro__autor">{autor}</p>
    </article>
  )
}

export default Libro
