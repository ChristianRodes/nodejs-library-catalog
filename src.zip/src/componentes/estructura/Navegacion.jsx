import "./Navegacion.css"

const Navegacion = () => {
  return (
    <nav className="navegacion">
      <ul className="navegacion__lista">
        <li className="navegacion__item">Inicio</li>
        <li className="navegacion__item">Libros</li>
        <li className="navegacion__item">Contacto</li>
      </ul>
    </nav>
  )
}

export default Navegacion
