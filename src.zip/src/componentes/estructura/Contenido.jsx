import "./Contenido.css"
import ListadoLibros from "../ListadoLibros"

const Contenido = () => {
  return (
    <main className="contenido">
      <ListadoLibros />
    </main>
  )
}

export default Contenido
