import "./PiePagina.css"

const PiePagina = () => {
  return (
    <footer className="pie-pagina">
      <p className="pie-pagina__texto">
        © 2026 · Biblioteca · DAW
      </p>
    </footer>
  )
}

export default PiePagina
