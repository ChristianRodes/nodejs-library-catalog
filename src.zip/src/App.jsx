import ListadoLibros from "./componentes/ListadoLibros"

function App() {
  return (
    <main>
      <h1>Biblioteca</h1>
      <ListadoLibros />
    </main>
  )
}

export default App
